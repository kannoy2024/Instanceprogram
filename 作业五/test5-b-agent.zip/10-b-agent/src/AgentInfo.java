
interface AgentInfo {

	public abstract String encryptName(String inputStr);

	public abstract String encryptCode(String code);

	public abstract void log(String lastNm, String firstNm, String code);

}