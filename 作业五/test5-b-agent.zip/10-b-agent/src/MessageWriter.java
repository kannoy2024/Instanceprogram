import java.sql.SQLException;
import java.util.*;

public interface MessageWriter {
	public void logMsg(String lastNm, String firstNm, String code);
}
