

/*==============================================*/
/* Interface for the implementation part of the bridge pattern
/*==============================================*/

public interface GeoForm {

   public abstract double computeVolume();

}